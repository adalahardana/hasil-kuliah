<?php 
    
?>
<div class="container">
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3">Data</h3>
            <ul class="breadcrumbs mb-3">
                <li class="nav-home">
                    <a href="dashboard">
                    <i class="icon-home"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                    <a href="">Data</a>
                </li>
            </ul>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4 class="card-title">Data</h4>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTambah">
                            Tambah
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="basic-datatables" class="display table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>asd</th>
                                        <th>asd</th>
                                        <th>asd</th>
                                        <th>asd</th>
                                        <th>asd</th>
                                        <th>...</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        
                                    ?>
                                        <tr>
                                            <td>asd</td>
                                            <td>asd</td>
                                            <td>asd</td>
                                            <td>asd</td>
                                            <td>asd</td>
                                            <td>
                                                <button type="button" class="btn btn-icon btn-info" data-bs-toggle="modal" data-bs-target="#modalDetail"><i class="fas fa-info"></i></button>
                                                <button type="button" class="btn btn-icon btn-warning" data-bs-toggle="modal" data-bs-target="#modalEdit"><i class="fas fa-pen"></i></button>
                                                <button type="button" class="btn btn-icon btn-danger" data-bs-toggle="modal" data-bs-target="#modalHapus"><i class="fas fa-trash"></i></button>
                                            </td>
                                        </tr>
                                        <!-- Modal Detail -->
                                        <div class="modal fade" id="modalDetail" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Detail Data</h5>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p>Data: Data</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Modal Edit -->
                                        <div class="modal fade" id="modalEdit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Edit Data</h5>
                                                    </div>
                                                    <form action="" method="post">
                                                        <div class="modal-body">
                                                            <div class="mb-3">
                                                                <label for="data" class="form-label">data</label>
                                                                <input value="data" type="text" class="form-control" name="data" id="data" placeholder="data" required>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button class="btn btn-primary" type="submit" name="update">Edit</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Modal Hapus -->
                                        <div class="modal fade" id="modalHapus" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Hapus Data</h5>
                                                    </div>
                                                    <form action="" method="post">
                                                        <div class="modal-body">
                                                            <p>Yakin ingin hapus?</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button class="btn btn-primary" value="" type="submit" name="delete">Hapus</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                        
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah -->
<div class="modal fade" id="modalTambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
            </div>
            <form action="" method="post">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="data" class="form-label">data</label>
                        <input type="text" class="form-control" name="data" id="data" placeholder="data" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" type="submit" name="add">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>