<div class="container-xxl py-5">
    <div class="container">
        <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h6 class="section-title bg-white text-center text-primary px-3"></h6>
            <h1 class="mb-5">Merchandise</h1>
        </div>
        <div class="row gap-5 justify-content-center">
            <?php 
                $getMerchandise = mysqli_query($koneksi, "SELECT * FROM merchandise");
                foreach ($getMerchandise as $key => $m) {
            ?>
            <div class="col-lg-3 col-md-6 wow fadeInUp bg-gelap" data-wow-delay="0.1s">
                <div class="team-item bg-gelap mt-3">
                    <div class="overflow-hidden">
                        <img class="img-fluid" src="<?= $m['image_url']; ?>" alt="">
                    </div>
                    <div class="text-center p-4">
                        <h5 class="mb-0 text-light"><?= $m['name']; ?></h5>
                        <small class="text-light"><?= $m['description']; ?></small>
                        <h5 class="mb-0 text-light"><?= $m['price']; ?></h5>
                    </div>
                    <div class="position-relative d-flex justify-content-center mb-3">
                        <div class="bg-hijau d-flex justify-content-center py-1">
                            <a class="btn btn-sm-square btn-light mx-1" href="beli?order=merchandise&merch=<?= $m['merch_id']; ?>"><i class="fa-solid fa-cart-shopping"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
</div>