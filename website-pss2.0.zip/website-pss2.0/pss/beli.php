<div class="container-fluid bg-primary mb-5 page-header">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10 text-center">
                <h1 class="display-3 text-white">Store</h1>
            </div>
        </div>
    </div>
</div>

<?php 
    if (!isset($_SESSION['userLogin'])) {
        header('Location: login.php');
    }

    $data = [];
    $tipe = array_keys($_GET)[2];
    $id = $sql = "";
    $order = $_GET['order'];
    if ($_GET['order'] == 'tiket') {
        $id = $_GET['ticket'];
        $query = mysqli_query($koneksi, "SELECT * FROM matches JOIN tickets ON matches.match_id = tickets.match_id WHERE matches.match_id = '$id'");
        while ($row = mysqli_fetch_assoc($query)) {
            $data[$row['category']] = $row;
        }
    } else {
        $id = $_GET['merch'];
        $query = mysqli_query($koneksi, "SELECT * FROM merchandise WHERE merch_id = '$id'");
        $data = mysqli_fetch_array($query);
    }

    if (isset($_POST['beli'])) {
        $id_beli = $_POST['beli'];
        $jumlah = $_POST['jumlah'];
        $harga = preg_replace('/[^0-9]/', '', $_POST['harga']);
        $tgl = date('Y-m-d');
        $total = preg_replace('/[^0-9]/', '', $_POST['total']);
        $user = $_SESSION['userLogin']['user_id'];
        

        $query = mysqli_query($koneksi, "INSERT INTO orders (user_id, order_date, total_price, status) VALUES ('$user', '$tgl', '$total', 'diproses')");
        if ($query) {
            $idtadi = mysqli_insert_id($koneksi);

            $querylagi = mysqli_query($koneksi, "INSERT INTO order_items (order_id, item_type, item_ref_id, quantity, unit_price) 
                VALUES ('$idtadi', '$tipe', '$id_beli', '$jumlah', '$harga')");
            
            if (!$querylagi) {
                echo "Gagal insert ke order_items: " . mysqli_error($koneksi);
            }
        } else {
            echo "Gagal insert ke orders: " . mysqli_error($koneksi);
        }

    }

?>
<!-- Contact Start -->
<div class="container-xxl">
    <div class="container">
        <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h6 class="section-title bg-white text-center text-primary px-3"></h6>
            <h1 class="mb-5"><?= $order; ?></h1>
        </div>
        <?php if ($data == null) { ?>
            <div class="text-center">
                Tiket belum ada
            </div>
        <?php } else { ?>
            <div class="row g-4">
                <?php if ($_GET['order'] == 'tiket') { ?>
                <div class="col-5 wow fadeInUp" data-wow-delay="0.5s">
                    <p class="d-inline-flex gap-1"> 
                        <button class="btn btn-primary active" id="btn-ekonomi" type="button" data-bs-toggle="collapse" data-bs-target="#collapse1" aria-expanded="true" aria-controls="collapse1">
                            Ekonomi
                        </button>   
                        <button class="btn btn-primary" id="btn-vip" type="button" data-bs-toggle="collapse" data-bs-target="#collapse2" aria-expanded="false" aria-controls="collapse2">
                            VIP
                        </button>
                    </p> 
                    <div id="accordionTiket"> 
                        <div class="collapse show" id="collapse1" data-bs-parent="#accordionTiket"> 
                            <div class="card card-body">
                                <form action="" method="post">
                                    <div class="row g-3">
                                        <div class="col-12">
                                            <div class="form-floating">
                                                <input value="Rp. <?= number_format($data['Ekonomi']['price'], 0, ',', '.'); ?>" type="text" class="form-control" id="harga" name="harga" readonly>
                                                <label for="harga">Harga</label>
                                            </div>
                                        </div>
                                        <div class="col-12 d-flex justify-content-start align-items-center gap-2">
                                            <label for="jumlah-barang">Jumlah</label>
                                            <button type="button" class="btn btn-outline-dark" onclick="ubahJumlah(-1)">-</button>
                                            <input type="text" class="form-control text-center <?= isset($errAdd['jumlah']) ? "is-invalid" : ""; ?> border-dark" id="jumlah-barang" name="jumlah" value="<?= isset($_POST['jumlah']) ? $_POST['jumlah'] : '1'; ?>" readonly style="width: 50px;">
                                            <button type="button" class="btn btn-outline-dark" onclick="ubahJumlah(1)">+</button>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-floating">
                                                <input value="Rp. <?= number_format($data['Ekonomi']['price'], 0, ',', '.'); ?>" type="text" class="form-control" id="total" name="total" readonly>
                                                <label for="total">Total</label>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <button class="btn btn-primary w-100 py-3" type="submit" name="beli" value="<?= $data['Ekonomi']['ticket_id']; ?>">Send Message</button>
                                        </div>
                                    </div>
                                </form>
                            </div> 
                        </div>
                        <div class="collapse" id="collapse2" data-bs-parent="#accordionTiket"> 
                            <div class="card card-body">
                                <form action="" method="post">
                                    <div class="row g-3">
                                        <div class="col-12">
                                            <div class="form-floating">
                                                <input value="Rp. <?= number_format($data['VIP']['price'], 0, ',', '.'); ?>" type="text" class="form-control" id="harga" name="harga" readonly>
                                                <label for="harga">Harga</label>
                                            </div>
                                        </div>
                                        <div class="col-12 d-flex justify-content-start align-items-center gap-2">
                                            <label for="jumlah-barang">Jumlah</label>
                                            <button type="button" class="btn btn-outline-dark" onclick="ubahJumlah(-1)">-</button>
                                            <input type="text" class="form-control text-center <?= isset($errAdd['jumlah']) ? "is-invalid" : ""; ?> border-dark" id="jumlah-barang" name="jumlah" value="<?= isset($_POST['jumlah']) ? $_POST['jumlah'] : '1'; ?>" readonly style="width: 50px;">
                                            <button type="button" class="btn btn-outline-dark" onclick="ubahJumlah(1)">+</button>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-floating">
                                                <input value="Rp. <?= number_format($data['VIP']['price'], 0, ',', '.'); ?>" type="text" class="form-control" id="total" name="total" readonly>
                                                <label for="total">Total</label>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <button class="btn btn-primary w-100 py-3" type="submit" name="beli" value="<?= $data['VIP']['ticket_id']; ?>">Send Message</button>
                                        </div>
                                    </div>
                                </form>
                            </div> 
                        </div>
                    </div>
                </div>
                <?php } else { ?>
                <div class="col-5 wow fadeInUp" data-wow-delay="0.5s">
                    <form action="" method="post">
                        <div class="row g-3">
                            <div class="col-12">
                                <div class="form-floating">
                                    <input value="Rp. <?= number_format($data['price'], 0, ',', '.'); ?>" type="text" class="form-control" id="harga" name="harga" readonly>
                                    <label for="harga">Harga</label>
                                </div>
                            </div>
                            <div class="col-12 d-flex justify-content-start align-items-center gap-2">
                                <label for="jumlah-barang">Jumlah</label>
                                <button type="button" class="btn btn-outline-dark" onclick="ubahJumlah(-1)">-</button>
                                <input type="text" class="form-control text-center <?= isset($errAdd['jumlah']) ? "is-invalid" : ""; ?> border-dark" id="jumlah-barang" name="jumlah" value="<?= isset($_POST['jumlah']) ? $_POST['jumlah'] : '1'; ?>" readonly style="width: 50px;">
                                <button type="button" class="btn btn-outline-dark" onclick="ubahJumlah(1)">+</button>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <input value="Rp. <?= number_format($data['price'], 0, ',', '.'); ?>" type="text" class="form-control" id="total" name="total" readonly>
                                    <label for="total">Total</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <button class="btn btn-primary w-100 py-3" type="submit" name="beli" value="<?= $data['merch_id']; ?>">Send Message</button>
                            </div>
                        </div>
                    </form>
                </div>
                <?php } ?>
                <div class="col-2"></div>
                <div class="col-5 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="team-item bg-gelap">
                        <?php if ($_GET['order'] == 'tiket') { ?>
                        <div class="position-relative overflow-hidden">
                            <img class="img-fluid" src="img/hero.jpg" alt="">
                        </div>
                        <div class="text-center p-4 pb-0">
                            <h5 class="mb-4 text-light">PSS Sleman vs <?= $data['Ekonomi']['opponent']; ?></h5>
                        </div>
                        <div class="d-flex border-top">
                            <small class="text-light flex-fill text-center border-end py-2"><i class="fa fa-user-tie me-2"></i><?= $data['Ekonomi']['match_date']; ?></small>
                            <small class="text-light flex-fill text-center py-2"><i class="fa fa-user me-2"></i><?= $data['Ekonomi']['location']; ?></small>
                        </div>
                        <?php } else { ?>
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="<?= $data['image_url']; ?>" alt="">
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0 text-light"><?= $data['name']; ?></h5>
                            <small class="text-light"><?= $data['description']; ?></small>
                            <h5 class="mb-0 text-light"><?= $data['price']; ?></h5>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>
<!-- Contact End -->
 <script>
    function hitungTotal() {
        const harga = parseInt(document.getElementById('harga').value.replace(/[^0-9]/g, ''));
        const jumlahBarang = parseInt(document.getElementById('jumlah-barang').value);

        const total = harga * jumlahBarang;
        document.getElementById('total').value = `Rp. ${total.toLocaleString('id-ID')}`;
    }

    function ubahJumlah(jumlah) {
        const input = document.getElementById('jumlah-barang');
        let nilai = parseInt(input.value);
        nilai += jumlah;
        if (nilai < 1) nilai = 1;
        input.value = nilai;
        hitungTotal();
    }

    document.addEventListener('DOMContentLoaded', () => {
        document.getElementById('jumlah-barang').addEventListener('input', hitungTotal);
    });

    document.addEventListener('DOMContentLoaded', function () {
        const collapse1 = document.getElementById('collapse1');
        const collapse2 = document.getElementById('collapse2');
        const btnEkonomi = document.getElementById('btn-ekonomi');
        const btnVIP = document.getElementById('btn-vip');

        collapse1.addEventListener('show.bs.collapse', function () {
            btnEkonomi.classList.add('active');
            btnVIP.classList.remove('active');
        });

        collapse2.addEventListener('show.bs.collapse', function () {
            btnVIP.classList.add('active');
            btnEkonomi.classList.remove('active');
        });
    });
</script>
