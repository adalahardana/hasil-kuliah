<?php 
    if (isset($_POST['add'])) {
        $image_url = "";
        if(!empty($_FILES['image_url']['name'])) {
            $rand = rand();
            $filename = $_FILES['image_url']['name'];
            $image_url = 'img/'.$rand.'_'.$filename;
        } else {
            $image_url = "";
        }
        $name = $_POST['name'];
        $category = $_POST['category'];
        $price = $_POST['price'];
        $stock = $_POST['stock'];
        $description = $_POST['description'];

        move_uploaded_file($_FILES['image_url']['tmp_name'], './../'.$image_url);
        $query = mysqli_query($koneksi, "INSERT INTO merchandise VALUES ('', '$name', '$category', '$price', '$stock', '$description', '$image_url')");
    }
    if (isset($_POST['update'])) {
        $id = $_POST['update'];
        $image = $_POST['image'];
        $image_url = "";
        if(!empty($_FILES['image_url']['name'])) {
            $rand = rand();
            $filename = $_FILES['image_url']['name'];
            $image_url = 'img/'.$rand.'_'.$filename;
            move_uploaded_file($_FILES['image_url']['tmp_name'], './../'.$image_url);
        } else {
            $image_url = $image;
        }
        $name = $_POST['name'];
        $category = $_POST['category'];
        $price = $_POST['price'];
        $stock = $_POST['stock'];
        $description = $_POST['description'];

        $query = mysqli_query($koneksi, "CALL sp_update_merch('$id','$name','$category','$price','$stock','$description','$image_url');");
    }

    if (isset($_POST['delete'])) {
        $id = $_POST['delete'];
        
        $query = mysqli_query($koneksi, "DELETE FROM merchandise WHERE merch_id ='$id'");
    }
?>
<div class="container">
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3">Data Merchandise</h3>
            <ul class="breadcrumbs mb-3">
                <li class="nav-home">
                    <a href="dashboard">
                    <i class="icon-home"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                    <a href="">Data Merchandise</a>
                </li>
            </ul>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4 class="card-title">Data Merchandise</h4>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTambah">
                            Tambah
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="basic-datatables" class="display table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Gambar</th>
                                        <th>Nama</th>
                                        <th>Kategori</th>
                                        <th>Harga</th>
                                        <th>Stok</th>
                                        <th>...</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        $getAllTiket = mysqli_query($koneksi, "SELECT * FROM merchandise");
                                        foreach ($getAllTiket as $key => $m) {
                                    ?>
                                        <tr>
                                            <td><?= $key+1; ?></td>
                                            <td><img src="./../<?= $m['image_url']; ?>" alt="<?= $m['image_url']; ?>" width="100"></td>
                                            <td><?= $m['name']; ?></td>
                                            <td><?= $m['category']; ?></td>
                                            <td><?= $m['price']; ?></td>
                                            <td><?= $m['stock']; ?></td>
                                            <td>
                                                <button type="button" class="btn btn-icon btn-info" data-bs-toggle="modal" data-bs-target="#modalDetail<?= $m['merch_id']; ?>"><i class="fas fa-info"></i></button>
                                                <button type="button" class="btn btn-icon btn-warning" data-bs-toggle="modal" data-bs-target="#modalEdit<?= $m['merch_id']; ?>"><i class="fas fa-pen"></i></button>
                                                <button type="button" class="btn btn-icon btn-danger" data-bs-toggle="modal" data-bs-target="#modalHapus<?= $m['merch_id']; ?>"><i class="fas fa-trash"></i></button>
                                            </td>
                                        </tr>
                                        <!-- Modal Detail -->
                                        <div class="modal fade" id="modalDetail<?= $m['merch_id']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Detail Data</h5>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p class="fw-bold"><?= $m['name']; ?></p>
                                                        <img src="./../<?= $m['image_url']; ?>" alt="<?= $m['image_url']; ?>" width="300">
                                                        <p>Kategori : <?= $m['category']; ?></p>
                                                        <p>Harga : <?= $m['price']; ?></p>
                                                        <p>Stok : <?= $m['stock']; ?></p>
                                                        <p>Deskripsi : <?= $m['description']; ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Modal Edit -->
                                        <div class="modal fade" id="modalEdit<?= $m['merch_id']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Edit Data</h5>
                                                    </div>
                                                    <form action="" method="post" enctype="multipart/form-data">
                                                        <div class="modal-body">
                                                            <img src="./../<?= $m['image_url']; ?>" alt="<?= $m['image_url']; ?>" width="300" class="mb-3">
                                                            <input type="hidden" name="image" value="<?= $m['image_url']; ?>">
                                                            <div class="mb-3">
                                                                <label for="image_url" class="form-label">Gambar</label>
                                                                <input value="<?= $m['image_url'];?>" type="file" class="form-control" name="image_url" id="image_url" placeholder="Gambar">
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="name" class="form-label">Nama</label>
                                                                <input value="<?= $m['name'];?>" type="text" class="form-control" name="name" id="name" placeholder="Nama" required>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="category" class="form-label">Kategori</label>
                                                                <input value="<?= $m['category'];?>" type="text" class="form-control" name="category" id="category" placeholder="Kategori" required>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="price" class="form-label">Harga</label>
                                                                <input value="<?= $m['price'];?>" type="text" class="form-control" name="price" id="price" placeholder="Harga" required>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="stock" class="form-label">Stok</label>
                                                                <input value="<?= $m['stock'];?>" type="text" class="form-control" name="stock" id="stock" placeholder="Stok" required>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="description" class="form-label">Deskripsi</label>
                                                                <input value="<?= $m['description'];?>" type="text" class="form-control" name="description" id="description" placeholder="Deskripsi" required>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button class="btn btn-primary" type="submit" name="update" value="<?= $m['merch_id'];?>">Edit</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Modal Hapus -->
                                        <div class="modal fade" id="modalHapus<?= $m['merch_id']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Hapus Data</h5>
                                                    </div>
                                                    <form action="" method="post">
                                                        <div class="modal-body">
                                                            <p>Yakin ingin hapus? <?= $m['merch_id']; ?></p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button class="btn btn-primary" value="<?= $m['merch_id']; ?>" type="submit" name="delete">Hapus</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah -->
<div class="modal fade" id="modalTambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
            </div>
            <form action="" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="image_url" class="form-label">Gambar</label>
                        <input type="file" class="form-control" name="image_url" id="image_url" placeholder="Gambar" required>
                    </div>
                    <div class="mb-3">
                        <label for="name" class="form-label">Nama</label>
                        <input type="text" class="form-control" name="name" id="name" placeholder="Nama" required>
                    </div>
                    <div class="mb-3">
                        <label for="category" class="form-label">Kategori</label>
                        <input type="text" class="form-control" name="category" id="category" placeholder="Kategori" required>
                    </div>
                    <div class="mb-3">
                        <label for="price" class="form-label">Harga</label>
                        <input type="text" class="form-control" name="price" id="price" placeholder="Harga" required>
                    </div>
                    <div class="mb-3">
                        <label for="stock" class="form-label">Stok</label>
                        <input type="text" class="form-control" name="stock" id="stock" placeholder="Stok" required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Deskripsi</label>
                        <input type="text" class="form-control" name="description" id="description" placeholder="Deskripsi" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" type="submit" name="add">Tambah</button>
                </div>
            </form>
        </div>
    </div>
</div>