<div class="container-fluid p-0 mb-5">
    <div class="owl-carousel header-carousel position-relative">
        <div class="owl-carousel-item position-relative">
            <img class="img-fluid" src="img/hero1.jpeg" alt="">
            <div class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center" style="background: rgba(24, 29, 56, .7);">
                <div class="container">
                    <div class="row justify-content-start">
                        <div class="col-sm-10 col-lg-8">
                            <!-- <h5 class="text-light text-uppercase mb-3 animated slideInDown">Kata kata</h5> -->
                           <h1 class="display-3 fw-bold text-white text-uppercase animated slideInDown text-shadow-lg" style="text-shadow: 4px 4px 8px rgba(0,0,0,0.8);">
    PSS SLEMAN
</h1>
<p class="fs-4 text-white fst-italic animated fadeInUp" data-wow-delay="0.3s">
    <span style="color: #00ff88; font-weight: bold;">ORA MUNTIR</span>, SWASEMBADA SUPER ELJA!!!<br>
</p>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="container-xxl py-5">
    <div class="container">
        <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h6 class="section-title bg-white text-center text-hijau px-3"></h6>
            <h1 class="mb-5">Pertandingan Mendatang</h1>
        </div>
        <div class="row g-4 justify-content-center">
            <?php 
                $getMatchMendatang = mysqli_query($koneksi, "CALL `sp_get_match_schedule`();");
                foreach ($getMatchMendatang as $key => $mm) {
            ?>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="course-item bg-light">
                    <div class="position-relative overflow-hidden">
                        <img class="img-fluid" src="img/hero.jpg" alt="">
                        <div class="w-100 d-flex justify-content-center position-absolute bottom-0 start-0 mb-4">
                            <a href="beli?order=tiket&ticket=<?= $mm['match_id']; ?>" class="flex-shrink-0 btn btn-sm btn-primary px-3 border-end" style="border-radius: 30px 30px 30px 30px;">Tiket</a>
                        </div>
                    </div>
                    <div class="text-center p-4 pb-0">
                        <h5 class="mb-4">PSS Sleman vs <?= $mm['opponent']; ?></h5>
                    </div>
                    <div class="d-flex border-top">
                        <small class="flex-fill text-center border-end py-2"><i class="fa fa-user-tie text-light me-2"></i><?= $mm['match_date']; ?></small>
                        <small class="flex-fill text-center py-2"><i class="fa fa-user text-light me-2"></i><?= $mm['location']; ?></small>
                    </div>
                </div>
            </div>
            <?php 
                }
            ?>
        </div>
    </div>
</div>


<div class="container-xxl py-5 category">
    <div class="container">
        <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h6 class="section-title bg-white text-center text-light px-3"></h6>
            <h1 class="mb-5">Merchandise</h1>
        </div>
        <div class="row g-3">
            <div class="col-lg-7 col-md-6">
                <div class="row g-3">
                    <div class="col-lg-12 col-md-12 wow zoomIn" data-wow-delay="0.1s">
                        <a class="position-relative d-block overflow-hidden" href="">
                            <img class="img-fluid" src="img/p2.jpeg" alt="">
                        </a>
                    </div>
                    <div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.3s">
                        <a class="position-relative d-block overflow-hidden" href="">
                            <img class="img-fluid" src="img/p1.jpeg" alt="">
                        </a>
                    </div>
                    <div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.5s">
                        <a class="position-relative d-block overflow-hidden" href="">
                            <img class="img-fluid" src="img/p3.jpeg" alt="">
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-5 col-md-6 wow zoomIn" data-wow-delay="0.7s" style="min-height: 350px;">
                <a class="position-relative d-block h-100 overflow-hidden" href="">
                    <img class="img-fluid position-absolute w-100 h-100" src="img/p3.jpeg" alt="" style="object-fit: cover;">
                </a>
            </div>
        </div>
    </div>
</div>