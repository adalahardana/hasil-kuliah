-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 20 Bulan Mei 2025 pada 03.32
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pss`
--

DELIMITER $$
--
-- Prosedur
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_get_match_schedule` ()   BEGIN
    SELECT match_id, opponent, match_date, location
    FROM matches
    WHERE status = 'akan datang'
    ORDER BY match_date ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_get_orders_by_user` (IN `in_user_id` INT)   BEGIN
    SELECT
        u.name AS nama_pembeli,
        mr.name AS nama_merchandise,
        mr.category AS category_merch,
        m.opponent AS lawan,
        t.category AS category_tiket,
        oi.quantity,
        oi.unit_price,
        (oi.quantity * oi.unit_price) AS total,
        o.order_date
    FROM
        order_items oi
    JOIN orders o ON oi.order_id = o.order_id
    JOIN users u ON o.user_id = u.user_id
    LEFT JOIN merchandise mr ON oi.item_type = 'merch' AND oi.item_ref_id = mr.merch_id
    LEFT JOIN tickets t ON oi.item_type = 'ticket' AND oi.item_ref_id = t.ticket_id
    LEFT JOIN matches m ON t.match_id = m.match_id
    WHERE o.user_id = in_user_id
    ORDER BY o.order_date DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_get_user_orders` (IN `in_user_id` INT)   BEGIN
    SELECT o.order_id, o.order_date, o.total_price, o.status
    FROM orders o
    WHERE o.user_id = in_user_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_hitung_total_pendapatan_per_user` ()   BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_user_id INT;
    DECLARE v_total INT;
    
    DECLARE cur CURSOR FOR
        SELECT DISTINCT user_id FROM orders;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    CREATE TEMPORARY TABLE IF NOT EXISTS temp_pendapatan (
        user_id INT,
        total_pendapatan INT
    );

    TRUNCATE TABLE temp_pendapatan;

    OPEN cur;

    read_loop: LOOP
        FETCH cur INTO v_user_id;
        IF done THEN
            LEAVE read_loop;
        END IF;

        SELECT SUM(total_price)
        INTO v_total
        FROM orders
        WHERE user_id = v_user_id;

        INSERT INTO temp_pendapatan(user_id, total_pendapatan)
        VALUES (v_user_id, IFNULL(v_total, 0));
    END LOOP;

    CLOSE cur;

    SELECT * FROM temp_pendapatan;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_update_merch` (IN `in_merch_id` INT, IN `new_name` VARCHAR(255), IN `new_category` VARCHAR(255), IN `new_price` INT, IN `new_stock` INT, IN `new_description` TEXT, IN `new_image_url` VARCHAR(255))   BEGIN
    UPDATE merchandise SET 
    name = new_name, 
    category = new_category, 
    price = new_price, 
    stock = new_stock, 
    description = new_description, 
    image_url = new_image_url 
    WHERE merch_id = in_merch_id;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `competitions`
--

CREATE TABLE `competitions` (
  `competition_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `season` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `competitions`
--

INSERT INTO `competitions` (`competition_id`, `name`, `season`) VALUES
(1, 'Liga 1 Indonesia', '2023/2024'),
(2, 'Piala Presiden', '2023'),
(3, 'Liga 1 Indonesia', '2022/2023'),
(4, 'Piala Menpora', '2021'),
(5, 'Liga 1 Indonesia', '2021/2022');

-- --------------------------------------------------------

--
-- Struktur dari tabel `competition_stats`
--

CREATE TABLE `competition_stats` (
  `stat_id` int(11) NOT NULL,
  `competition_id` int(11) DEFAULT NULL,
  `win` int(11) DEFAULT NULL,
  `draw` int(11) DEFAULT NULL,
  `loss` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `competition_stats`
--

INSERT INTO `competition_stats` (`stat_id`, `competition_id`, `win`, `draw`, `loss`) VALUES
(1, 1, 12, 6, 4),
(2, 2, 2, 1, 1),
(3, 3, 10, 8, 6),
(4, 4, 1, 1, 2),
(5, 5, 8, 5, 7);

-- --------------------------------------------------------

--
-- Struktur dari tabel `log_harga`
--

CREATE TABLE `log_harga` (
  `log_id` int(11) NOT NULL,
  `merch_id` int(11) DEFAULT NULL,
  `nama_barang` varchar(100) DEFAULT NULL,
  `harga_lama` int(11) DEFAULT NULL,
  `harga_baru` int(11) DEFAULT NULL,
  `waktu` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `log_harga`
--

INSERT INTO `log_harga` (`log_id`, `merch_id`, `nama_barang`, `harga_lama`, `harga_baru`, `waktu`) VALUES
(1, 5, 'Poster Pemain', 25000, 30000, '2025-05-20 01:24:03');

-- --------------------------------------------------------

--
-- Struktur dari tabel `log_user_dihapus`
--

CREATE TABLE `log_user_dihapus` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `kta_number` varchar(50) DEFAULT NULL,
  `dihapus_pada` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `log_user_dihapus`
--

INSERT INTO `log_user_dihapus` (`log_id`, `user_id`, `nama`, `kta_number`, `dihapus_pada`) VALUES
(1, 111, 'asd', 'KTA123659', '2025-05-20 01:21:03');

-- --------------------------------------------------------

--
-- Struktur dari tabel `matches`
--

CREATE TABLE `matches` (
  `match_id` int(11) NOT NULL,
  `competition_id` int(11) DEFAULT NULL,
  `opponent` varchar(100) DEFAULT NULL,
  `match_date` date DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `status` enum('selesai','akan datang') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `matches`
--

INSERT INTO `matches` (`match_id`, `competition_id`, `opponent`, `match_date`, `location`, `status`) VALUES
(1, 1, 'Persib Bandung', '2024-02-12', 'Stadion Maguwoharjo', 'selesai'),
(2, 1, 'Arema FC', '2024-02-20', 'Stadion Kanjuruhan', 'selesai'),
(3, 2, 'PSIS Semarang', '2023-06-05', 'Stadion Maguwoharjo', 'selesai'),
(4, 3, 'Persebaya', '2023-03-15', 'Stadion Gelora Bung Tomo', 'selesai'),
(5, 1, 'Persija Jakarta', '2024-04-01', 'Stadion Maguwoharjo', 'akan datang'),
(7, 1, 'Barca', '2025-05-30', 'Taman Kampus', 'akan datang');

-- --------------------------------------------------------

--
-- Struktur dari tabel `merchandise`
--

CREATE TABLE `merchandise` (
  `merch_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `price` int(11) NOT NULL,
  `stock` int(11) NOT NULL,
  `description` text DEFAULT NULL,
  `image_url` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `merchandise`
--

INSERT INTO `merchandise` (`merch_id`, `name`, `category`, `price`, `stock`, `description`, `image_url`) VALUES
(3, 'Topi PSS', 'Aksesoris', 75000, 30, 'Topi snapback dengan logo PSS', 'img/p2.jpeg'),
(4, 'Kaos Latihan', 'Pakaian', 120000, 40, 'Kaos training resmi tim', 'img/p1.jpeg'),
(5, 'Poster Pemain', 'Merchandise', 30000, 56, 'Poster ukuran A3 para pemain', 'img/438600938_p3.jpeg');

--
-- Trigger `merchandise`
--
DELIMITER $$
CREATE TRIGGER `trg_log_perubahan_harga` AFTER UPDATE ON `merchandise` FOR EACH ROW BEGIN
    IF OLD.price <> NEW.price THEN
        INSERT INTO log_harga (merch_id, nama_barang, harga_lama, harga_baru)
        VALUES (OLD.merch_id, OLD.name, OLD.price, NEW.price);
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `order_date` datetime DEFAULT current_timestamp(),
  `total_price` int(11) NOT NULL,
  `status` enum('diproses','selesai','batal') DEFAULT 'diproses'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `order_date`, `total_price`, `status`) VALUES
(1, 101, '2024-05-10 10:00:00', 425000, 'selesai'),
(2, 102, '2024-05-11 12:15:00', 100000, 'selesai'),
(3, 103, '2024-05-12 09:30:00', 350000, 'diproses'),
(4, 101, '2024-05-12 11:00:00', 25000, 'selesai'),
(5, 104, '2024-05-13 08:20:00', 195000, 'diproses'),
(14, 109, '2025-05-14 00:00:00', 350000, 'diproses'),
(15, 109, '2025-05-14 00:00:00', 80000, 'diproses'),
(17, 109, '2025-05-14 00:00:00', 80000, 'diproses'),
(18, 109, '2025-05-20 00:00:00', 80000, 'diproses');

-- --------------------------------------------------------

--
-- Struktur dari tabel `order_items`
--

CREATE TABLE `order_items` (
  `item_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `item_type` enum('merch','ticket') DEFAULT NULL,
  `item_ref_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `order_items`
--

INSERT INTO `order_items` (`item_id`, `order_id`, `item_type`, `item_ref_id`, `quantity`, `unit_price`) VALUES
(1, 1, 'merch', 3, 1, 350000),
(2, 1, 'merch', 4, 1, 75000),
(3, 2, 'merch', 3, 1, 100000),
(4, 3, 'merch', 5, 1, 350000),
(5, 4, 'merch', 5, 1, 25000),
(6, 14, 'merch', 5, 1, 350000),
(7, 15, 'ticket', 205, 1, 80000),
(9, 17, 'ticket', 204, 1, 80000),
(10, 18, 'ticket', 204, 1, 80000);

--
-- Trigger `order_items`
--
DELIMITER $$
CREATE TRIGGER `trg_orderitem_insert_kurangi_stok` AFTER INSERT ON `order_items` FOR EACH ROW BEGIN
    IF NEW.item_type = 'merch' THEN
        UPDATE merchandise
        SET stock = stock - NEW.quantity
        WHERE merch_id = NEW.item_ref_id;
    ELSEIF NEW.item_type = 'ticket' THEN
        UPDATE tickets
        SET stock = stock - NEW.quantity
        WHERE ticket_id = NEW.item_ref_id;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `players`
--

CREATE TABLE `players` (
  `player_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `position` varchar(50) NOT NULL,
  `birth_date` date DEFAULT NULL,
  `nationality` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `players`
--

INSERT INTO `players` (`player_id`, `name`, `position`, `birth_date`, `nationality`) VALUES
(1, 'Bagus Nirwanto', 'Bek', '1993-05-06', 'Indonesia'),
(2, 'Kim Kurniawan', 'Gelandang', '1990-03-23', 'Indonesia'),
(3, 'Irfan Bachdim', 'Penyerang', '1988-08-11', 'Indonesia'),
(4, 'Misbakus Solikin', 'Gelandang', '1992-09-01', 'Indonesia'),
(5, 'Ega Rizky', 'Kiper', '1992-08-23', 'Indonesia');

-- --------------------------------------------------------

--
-- Struktur dari tabel `team_membership`
--

CREATE TABLE `team_membership` (
  `member_id` int(11) NOT NULL,
  `competition_id` int(11) DEFAULT NULL,
  `player_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `team_membership`
--

INSERT INTO `team_membership` (`member_id`, `competition_id`, `player_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 2, 1),
(5, 2, 4);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tickets`
--

CREATE TABLE `tickets` (
  `ticket_id` int(11) NOT NULL,
  `match_id` int(11) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `price` int(11) NOT NULL,
  `stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tickets`
--

INSERT INTO `tickets` (`ticket_id`, `match_id`, `category`, `price`, `stock`) VALUES
(202, 1, 'Ekonomi', 75000, 200),
(203, 2, 'VIP', 160000, 80),
(204, 5, 'Ekonomi', 80000, 179),
(205, 5, 'VIP', 155000, 90),
(209, 2, 'Ekonomi', 150000, 100);

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','customer') NOT NULL,
  `kta_number` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`user_id`, `name`, `password`, `role`, `kta_number`, `created_at`) VALUES
(101, 'agung_pss', 'hashedpassword101', '', 'KTA123456', '2025-05-13 20:21:37'),
(102, 'dina_bcs', 'hashedpassword102', '', 'KTA654321', '2025-05-13 20:21:37'),
(103, 'admin_pss', 'admin', 'admin', 'admin', '2025-05-13 20:21:37'),
(104, 'reza_sleman', 'hashedpassword104', '', 'KTA111222', '2025-05-13 20:21:37'),
(105, 'fitri_pss', 'hashedpassword105', '', 'KTA333444', '2025-05-13 20:21:37'),
(108, 'asd', '123', '', 'KTA123123', '0000-00-00 00:00:00'),
(109, 'Nur Muhammad', '123', '', 'KTA123122', '0000-00-00 00:00:00');

--
-- Trigger `users`
--
DELIMITER $$
CREATE TRIGGER `trg_log_user_dihapus` AFTER DELETE ON `users` FOR EACH ROW BEGIN
    INSERT INTO log_user_dihapus (user_id, nama, kta_number)
    VALUES (OLD.user_id, OLD.name, OLD.kta_number);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `view_detail_penjualan_merch`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `view_detail_penjualan_merch` (
`nama_pembeli` varchar(100)
,`nama_merchandise` varchar(100)
,`category` varchar(50)
,`quantity` int(11)
,`unit_price` int(11)
,`total` bigint(21)
,`order_date` datetime
);

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `view_detail_penjualan_tiket`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `view_detail_penjualan_tiket` (
`nama_pembeli` varchar(100)
,`lawan` varchar(100)
,`category` varchar(50)
,`quantity` int(11)
,`unit_price` int(11)
,`total` bigint(21)
,`order_date` datetime
);

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `view_merchandise_terlaris`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `view_merchandise_terlaris` (
`merch_id` int(11)
,`name` varchar(100)
,`category` varchar(50)
,`price` int(11)
,`stock` int(11)
,`description` text
,`image_url` text
,`total_terjual` decimal(32,0)
);

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `view_merch_stok_terbanyak`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `view_merch_stok_terbanyak` (
`merch_id` int(11)
,`name` varchar(100)
,`category` varchar(50)
,`price` int(11)
,`stock` int(11)
,`description` text
,`image_url` text
);

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `view_merch_stok_tersedikit`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `view_merch_stok_tersedikit` (
`merch_id` int(11)
,`name` varchar(100)
,`category` varchar(50)
,`price` int(11)
,`stock` int(11)
,`description` text
,`image_url` text
);

-- --------------------------------------------------------

--
-- Struktur untuk view `view_detail_penjualan_merch`
--
DROP TABLE IF EXISTS `view_detail_penjualan_merch`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_detail_penjualan_merch`  AS SELECT `u`.`name` AS `nama_pembeli`, `m`.`name` AS `nama_merchandise`, `m`.`category` AS `category`, `oi`.`quantity` AS `quantity`, `oi`.`unit_price` AS `unit_price`, `oi`.`quantity`* `oi`.`unit_price` AS `total`, `o`.`order_date` AS `order_date` FROM (((`order_items` `oi` join `orders` `o` on(`oi`.`order_id` = `o`.`order_id`)) join `users` `u` on(`o`.`user_id` = `u`.`user_id`)) join `merchandise` `m` on(`oi`.`item_type` = 'merch' and `oi`.`item_ref_id` = `m`.`merch_id`)) ORDER BY `o`.`order_date` DESC ;

-- --------------------------------------------------------

--
-- Struktur untuk view `view_detail_penjualan_tiket`
--
DROP TABLE IF EXISTS `view_detail_penjualan_tiket`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_detail_penjualan_tiket`  AS SELECT `u`.`name` AS `nama_pembeli`, `m`.`opponent` AS `lawan`, `t`.`category` AS `category`, `oi`.`quantity` AS `quantity`, `oi`.`unit_price` AS `unit_price`, `oi`.`quantity`* `oi`.`unit_price` AS `total`, `o`.`order_date` AS `order_date` FROM ((((`order_items` `oi` join `orders` `o` on(`oi`.`order_id` = `o`.`order_id`)) join `users` `u` on(`o`.`user_id` = `u`.`user_id`)) join `tickets` `t` on(`oi`.`item_type` = 'ticket' and `oi`.`item_ref_id` = `t`.`ticket_id`)) join `matches` `m` on(`t`.`match_id` = `m`.`match_id`)) ORDER BY `o`.`order_date` DESC ;

-- --------------------------------------------------------

--
-- Struktur untuk view `view_merchandise_terlaris`
--
DROP TABLE IF EXISTS `view_merchandise_terlaris`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_merchandise_terlaris`  AS SELECT `m`.`merch_id` AS `merch_id`, `m`.`name` AS `name`, `m`.`category` AS `category`, `m`.`price` AS `price`, `m`.`stock` AS `stock`, `m`.`description` AS `description`, `m`.`image_url` AS `image_url`, sum(`oi`.`quantity`) AS `total_terjual` FROM (`order_items` `oi` join `merchandise` `m` on(`oi`.`item_type` = 'merch' and `oi`.`item_ref_id` = `m`.`merch_id`)) GROUP BY `oi`.`item_ref_id` ORDER BY sum(`oi`.`quantity`) DESC ;

-- --------------------------------------------------------

--
-- Struktur untuk view `view_merch_stok_terbanyak`
--
DROP TABLE IF EXISTS `view_merch_stok_terbanyak`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_merch_stok_terbanyak`  AS SELECT `merchandise`.`merch_id` AS `merch_id`, `merchandise`.`name` AS `name`, `merchandise`.`category` AS `category`, `merchandise`.`price` AS `price`, `merchandise`.`stock` AS `stock`, `merchandise`.`description` AS `description`, `merchandise`.`image_url` AS `image_url` FROM `merchandise` ORDER BY `merchandise`.`stock` DESC LIMIT 0, 3 ;

-- --------------------------------------------------------

--
-- Struktur untuk view `view_merch_stok_tersedikit`
--
DROP TABLE IF EXISTS `view_merch_stok_tersedikit`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_merch_stok_tersedikit`  AS SELECT `merchandise`.`merch_id` AS `merch_id`, `merchandise`.`name` AS `name`, `merchandise`.`category` AS `category`, `merchandise`.`price` AS `price`, `merchandise`.`stock` AS `stock`, `merchandise`.`description` AS `description`, `merchandise`.`image_url` AS `image_url` FROM `merchandise` ORDER BY `merchandise`.`stock` ASC LIMIT 0, 3 ;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `competitions`
--
ALTER TABLE `competitions`
  ADD PRIMARY KEY (`competition_id`);

--
-- Indeks untuk tabel `competition_stats`
--
ALTER TABLE `competition_stats`
  ADD PRIMARY KEY (`stat_id`),
  ADD KEY `competition_id` (`competition_id`);

--
-- Indeks untuk tabel `log_harga`
--
ALTER TABLE `log_harga`
  ADD PRIMARY KEY (`log_id`);

--
-- Indeks untuk tabel `log_user_dihapus`
--
ALTER TABLE `log_user_dihapus`
  ADD PRIMARY KEY (`log_id`);

--
-- Indeks untuk tabel `matches`
--
ALTER TABLE `matches`
  ADD PRIMARY KEY (`match_id`),
  ADD KEY `competition_id` (`competition_id`);

--
-- Indeks untuk tabel `merchandise`
--
ALTER TABLE `merchandise`
  ADD PRIMARY KEY (`merch_id`);

--
-- Indeks untuk tabel `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeks untuk tabel `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `item_ref_id` (`item_ref_id`);

--
-- Indeks untuk tabel `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`player_id`);

--
-- Indeks untuk tabel `team_membership`
--
ALTER TABLE `team_membership`
  ADD PRIMARY KEY (`member_id`),
  ADD KEY `competition_id` (`competition_id`),
  ADD KEY `player_id` (`player_id`);

--
-- Indeks untuk tabel `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ticket_id`),
  ADD KEY `match_id` (`match_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `kta_number` (`kta_number`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `competitions`
--
ALTER TABLE `competitions`
  MODIFY `competition_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `competition_stats`
--
ALTER TABLE `competition_stats`
  MODIFY `stat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `log_harga`
--
ALTER TABLE `log_harga`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `log_user_dihapus`
--
ALTER TABLE `log_user_dihapus`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `matches`
--
ALTER TABLE `matches`
  MODIFY `match_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `merchandise`
--
ALTER TABLE `merchandise`
  MODIFY `merch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT untuk tabel `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT untuk tabel `order_items`
--
ALTER TABLE `order_items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `players`
--
ALTER TABLE `players`
  MODIFY `player_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `team_membership`
--
ALTER TABLE `team_membership`
  MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `tickets`
--
ALTER TABLE `tickets`
  MODIFY `ticket_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=210;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `competition_stats`
--
ALTER TABLE `competition_stats`
  ADD CONSTRAINT `competition_stats_ibfk_1` FOREIGN KEY (`competition_id`) REFERENCES `competitions` (`competition_id`);

--
-- Ketidakleluasaan untuk tabel `matches`
--
ALTER TABLE `matches`
  ADD CONSTRAINT `matches_ibfk_1` FOREIGN KEY (`competition_id`) REFERENCES `competitions` (`competition_id`);

--
-- Ketidakleluasaan untuk tabel `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Ketidakleluasaan untuk tabel `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`);

--
-- Ketidakleluasaan untuk tabel `team_membership`
--
ALTER TABLE `team_membership`
  ADD CONSTRAINT `team_membership_ibfk_1` FOREIGN KEY (`competition_id`) REFERENCES `competitions` (`competition_id`),
  ADD CONSTRAINT `team_membership_ibfk_2` FOREIGN KEY (`player_id`) REFERENCES `players` (`player_id`);

--
-- Ketidakleluasaan untuk tabel `tickets`
--
ALTER TABLE `tickets`
  ADD CONSTRAINT `tickets_ibfk_1` FOREIGN KEY (`match_id`) REFERENCES `matches` (`match_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
